package filesDirectories;

import java.io.File;
import java.io.IOException;

public class FileCreation {

	public static void main(String[] args) {
		
		/* 
		 * To simply create a file, the path as to where you want the file to be created has to be given along with its new given name
		 * At runtime, no actual file has actually been created, just a file object, an abstract representation of one
		 * The 'File' class has no method to write to it, but does have methods to figure out metadata, setting file permissions, renaming, etc.
		 */
		File exampleFile = new File("C:\\Users\\TheUser\\Desktop\\exampleFile.txt");
		
		// Creates an actual file that can be seen within the desktop file exporer
		try {
			// The 'createNewFile()' method returns a boolean value
			boolean fileCreated = exampleFile.createNewFile();
			
			System.out.println(fileCreated);
		} catch(IOException ioException) {
			
		}

	}

}
