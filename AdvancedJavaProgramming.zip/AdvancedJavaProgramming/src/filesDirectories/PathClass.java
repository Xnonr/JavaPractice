package filesDirectories;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PathClass {

	public static void main(String[] args) {
		
		// Class path can check whether or not a file exists and delete said file if it does
		Path path = Paths.get("HelloWorld.txt");
		
		// Various methods available to gather information about files, including but not limited to Parent and Root directories, file name, etc.
		System.out.println(path.getParent());
		System.out.println(path.getRoot());
		System.out.println(path.getFileName());
		
		try {
			Files.deleteIfExists(path);
		} catch(IOException ioException) {
			Logger.getLogger(PathClass.class.getName()).log(Level.SEVERE, null, ioException);
		}

	}

}
