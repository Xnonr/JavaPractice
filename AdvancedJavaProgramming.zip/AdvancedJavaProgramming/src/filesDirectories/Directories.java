package filesDirectories;

import java.io.File;

public class Directories {

	public static void main(String[] args) {
		
		// FilenameFilter tutorial is FUBAR
		// Filters out any folders, as their names do not contain a dot
//		FilenameFilter filter (file, fileName) -> {
//			return fileName.contains(".");
//		};
//		
//		// Lists everything within the current directory
//		String[] contents = new File(".").list(filter);
//		
//		for(String file: contents) {
//			System.out.println(file);
//		}
//		
//		// Creates a new directory / folder
//		new File("exampleDirectory").mkdir();
	}
}
