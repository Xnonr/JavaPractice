package filesDirectories;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class CopyingFiles {

	public static void main(String[] args) {
		
		Path source = Paths.get("C:\\Users\\TheUser\\Desktop\\example.txt");
		Path destination = Paths.get("C:\\Users\\TheUser\\Desktop\\copiedExample.txt");
		
		try {
			// Copies a file from a source directory to a destination directory
			//Files.copy(source, destination);
			
			// Optional arguments possible
			Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
			
		} catch(IOException ioException) {
			ioException.printStackTrace();
		}

	}

}
