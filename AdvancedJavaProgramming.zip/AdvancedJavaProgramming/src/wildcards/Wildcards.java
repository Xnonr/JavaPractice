package wildcards;

import java.util.ArrayList;
import java.util.List;

// In Java a wildcard is essentially an unknown type and can provide more flexibility when writing methods, removing potential duplicates
// Generally a bad idea to use wildcards as return types for a method

public class Wildcards {

	public static void main(String[] args) {
		
		// List of planets
		List<Planet> planets = new ArrayList();
		planets.add(new Planet());
		planets.add(new Planet());
		printPlanets(planets);
		
		// List of cities
		List<City> cities = new ArrayList();
		cities.add(new City());
		cities.add(new City());
		printPlanets(cities);
		
		// List of allegiances
		List<Allegiance> allegiances = new ArrayList();
		allegiances.add(new Allegiance());
		allegiances.add(new Allegiance());
		printPlanets(allegiances);
		
		addCityToList(cities);
		addCityToList(planets);
	
	}
	
	// Passing in a list which provides data which is used inside the method, so this is an in-variable and extends should be used
	static void printPlanets(List<? extends Planet> planets) {
		for(int index = 0; index < planets.size(); index++) {
			System.out.println(planets.get(index).toString() + " " + (index + 1));
		}
		
		System.out.println();
	}
	
	// Wildcards also can be used to specify that super types can be used when a sub-type is specified
	// Giving additional data by adding to the list, so this is an out-variable and super should be used
	static void addCityToList(List<? super City> cities) {
		cities.add(new City());
		
		System.out.println();
	}
}
