package wildcards;

public class Planet {

	public int population = 1000000;
	
	@Override
	public String toString() {
		return("Planet");
	}
	
	public int getPopulation() {
		return(population);
	}
	
	public void setPopulation(int newPopulation) {
		this.population = newPopulation;
	}
}
