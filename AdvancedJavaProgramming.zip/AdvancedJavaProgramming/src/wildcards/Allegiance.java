package wildcards;

public class Allegiance extends Planet {

	public int population = 500000;
	
	@Override
	public String toString() {
		return("Loyal Population");
	}
	
	public int getPopulation() {
		return(population);
	}
	
	public void setPopulation(int newPopulation) {
		this.population = newPopulation;
	}
}
