package wildcards;

public class City extends Planet {

	@Override
	public String toString() {
		return("City");
	}
}
