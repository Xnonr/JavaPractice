package generics;

import java.util.ArrayList;
import java.util.List;

// Generics are a way to tell the compiler what type of object a collection can contain
public class Generics {

	public static void main(String[] args) {
		
		// Both examples carry out the same task:
		// Creating an array list, adding a single string to it, retrieving the list's first element and finally printing said element

		// Example without Generics:
		// Raw List Type
		List firstNames1 = new ArrayList();
		firstNames1.add("Kelly");
		
		// The first element needs to be cast into a string
		String firstName1 = (String) firstNames1.get(0);
		
		System.out.println("First Name: " + firstName1);
		
		// Nothing prevents other data types from being added to the list
		firstNames1.add(5);
		
		System.out.println(firstNames1);
		System.out.println("\n");
		
		
		// Example with Generics:
		// Prevents adding anything other than a String data type to the current list
		List<String> firstNames2 = new ArrayList();
		firstNames2.add("Kelly");
		
		// No casting required
		String firstName2 = firstNames2.get(0);
		
		System.out.println("First Name: " + firstName2);
		
	}
}
