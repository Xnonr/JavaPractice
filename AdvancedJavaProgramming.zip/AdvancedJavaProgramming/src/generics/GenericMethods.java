package generics;

import java.util.ArrayList;
import java.util.List;


// Generic methods in java are methods that allow you to create a new type parameter just for that method
// Useful when writing a method but want to be flexible in terms of the types of object which can be passed in
public class GenericMethods {

	static Character[] charArray = {'s', 't', 'a', 'r', 'w', 'a', 'r', 's'};
	static Integer[] intArray = {10, 9 ,8 , 7, 5, 4, 3, 2, 1};
	static Boolean[] boolArray = {true, false, true, true, false};
	
	public static void main(String[] args) {
		List<Character> charList = arrayToList1(charArray, new ArrayList<>());
		List<Character> intList = arrayToList1(intArray, new ArrayList<>());
		List<Character> boolList = arrayToList1(boolArray, new ArrayList<>());
	}
	
	// Within Java, Object is a parent type of all other object types, however by using Objects type safety is lost
	// Issues however can arise, as miscasting can arise that the compiler will not detect and may only appear at runtime
	public static List arrayToList1(Object[] objectArray, List<Object> objectList) {
		for(Object object : objectArray) {
			objectList.add(object);
		}
		
		return objectList;
	}
	
	// Generic version of the above method, avoids its potential pitfalls
	public static <T> List<T> arrayToList2(T[] genericArray, List<T> genericList) {
		for(T object : genericArray) {
			genericList.add(object);
		}
		
		return genericList;
	}
}
