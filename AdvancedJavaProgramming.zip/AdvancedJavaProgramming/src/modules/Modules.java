package modules;

/* Modules:
 * A group of related code and sometimes other resources
 * 
 * It also has to have a unique name to the global name space, just like Java packages
 * com.mycompany.mypackage vs. com.mycompany.mymodule
 * 
 * Contains some information describing itself
 * By default, all information about a module is hidden from the outside world and inaccessible from outside the module, even if it is public
 * A descriptor specifies if the code within the module should be accessible to other modules, or if itself will use code from other modules
 * 
 * Easy way to encapsulate code, only code that is needed is available to the outside world, making code structuring much more manageable
 * 
 * 
 * Modularity makes it easier to write well encapsulated code by breaking up large code bases into small sections
 * Modules used to break up the previously monolithic JDK itself
 * This avoids issues such as old legacy code, backwards compatibility issues, security vulnerabilities from code portions that are unneeded, etc.
 * Can be used to create new or update existing Java application
 */

public class Modules {

	// To create a module, simply right click the Java project folder and select new Java Module Info
	
	// Real modularization, choosing what can and can't be seen by the outside world
	
	/* Importing packages and modules required by your own module uses the 'requires' keyword
	 * 'requires java.desktop;'
	 * 
	 * Importing a module called Scheduler located in a folder called scheduling
	 * 'import scheduling.Scheduler;'
	*/ 
	
	// Allowing other packages and modules to use your module uses the 'exports' keyword
	// exports modulesName;
	
	// Java Module Projects contain multiple modules, each with their own Java packages, classes and so forth
	// Module Info files are at the same level as the modules' packages
	
	/* Command Line Modular Project:
	 * 
	 * Compiling:
	 * '-d' - Flag to specify the output directory, in this case called 'outputDirectory'
	 * The output files must have the same name as the module, in this case 'helloworld'
	 * Next is the name of the java class to compile
	 * Because it is a modular application, the module-info.java file also has to be included for proper compilation
	 * 
	 * javac -d outputDirectory/helloworld src/hellowrod/com/greeting/HelloWorld.java src/helloworld/module-info.java
	 * 
	 * 
	 * Running:
	 * Module Path Flag - With modular applications, models are not resolved from the normal class path, but from the module path
	 * This avoid issues such as class path hell, which pop up when classes are duplicates or can't be found, for example
	 * The module-info files are relatively easy to index and tell the Java runtime and compiler exactly what dependencies they need
	 * Pass in the name of the directory where the compiled code is
	 * Then the module flag with the name of the module desired
	 * Then a slash with the class to be run
	 * Separate directories with a dot
	 * 
	 * java --module-path output --module helloworld/com.helloworld.HelloWorld 
	 * OR 
	 * java -p output -m helloworld/com.helloworld.HelloWorld 
	 */
}
