package Queues;

import java.util.LinkedList;

/*
 * A queue is a first in first out static structure
 * Useful when controlling access to shared resources
 */

public class StoreQueue {

	public static void main(String[] args) {
		
		// LinkedList implements the Queue interface within the Java API
		LinkedList<Customer> customerQueue = new LinkedList<Customer>();
		
		// The '.add()' method always adds an element to the tail end of a list
		customerQueue.add(new Customer("Leia"));
		customerQueue.add(new Customer("Luke"));
		customerQueue.add(new Customer("Anakin"));
		customerQueue.add(new Customer("Han"));
		customerQueue.add(new Customer("Chewbaka"));
		
		// First in, first out in that order
		System.out.println(customerQueue);
		
		serveCustomer(customerQueue);
		
		// Leia has been served and now no longer appears within the queue
		System.out.println(customerQueue);
		
	}
	
	// When a customer has been served, they should be removed from the queue, with the person ahead of the line always being the first removed
	static void serveCustomer(LinkedList<Customer> queue) {
		
		// Removes the first element of a list
		Customer firstInLine = queue.poll();
		firstInLine.serve();
	}

}
