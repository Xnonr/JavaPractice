package varargs;

// Useful when a method able to take in a variable length of arguments is desired
// varargs - Variable Length Arguments

public class Varargs {

	public static void main(String[] args) {
		String itemBlaster = "Blaster";
		String itemLightsaber = "Lightsaber";
		String itemRocketBoots = "Rocket Boots";
		
		String[] shoppingList1 = {itemBlaster, itemLightsaber, itemRocketBoots};
		String[] shoppingList2 = {"Bowcaster", "Communicator", "Droid", "Helmet", "Starfighter"};
		
		printShoppingList(itemBlaster, itemLightsaber, itemRocketBoots);
		printShoppingList(shoppingList1);
		printShoppingList(shoppingList2);
	}
	
	// Vararg method
	private static void printShoppingList(String... items) {
		System.out.println("SHOPPING LIST");
		
		for(int index = 0; index < items.length; index++) {
			System.out.println(index + 1 + ": " + items[index]);
		}
		
		System.out.println();
	}
}
