package Collections;

import java.util.LinkedList;

/*
 * A linked list is a doubly linked collection of elements, with each entry in the list also holding a reference to the address of the next and 
 * previous item within the list.
 * Their main advantage is that they are quick for inserting and removing elements within the middle of a list.
 * 
 * For placing many elements within the middle of a large existing list, linked lists are faster
 * For retrieving many elements from within an existing list, array lists are faster
 * 
 * Linked lists take up more memory due to the fact that they need to contain extra references for each of their entries
 */

public class LinkedListExample {

	public static void main(String[] args) {
		
		// If in doubt, use an array list
		
		// Often compared to array list as they both implement the list interface and therefore have many methods in common
		LinkedList<String> linkedList1 = new LinkedList<String>();
		
		linkedList1.add("A");
		linkedList1.add("B");
		
		// Inserting the letter 'C' at index 1, between letters 'A' and 'B'
		linkedList1.add(1, "C");
		
		System.out.println(linkedList1);
		
		// Remove the letter 'B' from the list
		linkedList1.remove("B");
		
		System.out.println(linkedList1);
		
		
	}

}
