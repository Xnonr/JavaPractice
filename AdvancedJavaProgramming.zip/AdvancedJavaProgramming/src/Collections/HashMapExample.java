package Collections;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/* 
 * HashMaps in Java are the equivalent of dictionaries in Python
 * Java has a dictionary but it is no longer in use and is considered outdated compared to HashMaps
 * Are unordered and do not allow duplicate keys, entries are stored by their contents and not their positions
 */
public class HashMapExample {

	public static void main(String[] args) {
		
		HashMap<String, String> starship = new HashMap<>();
		starship.put("Luke Skywalker", "T-65B X-Wing");
		starship.put("Han Solo", "YT-1300F Light Freighter");
		starship.put("Darth Vader", "Super Star Destroyer");
		
		// As duplicate keys are not allowed, a new entry with the same key but a different value will overwrite the previous value
		starship.put("Darth Vader", "TIE Advanced");
		
		// Null values are allowed
		starship.put("Yoda", null);
		starship.put(null, "The Void");
		
		System.out.println(starship);
		
		if(starship.containsKey("Han Solo")) {
			starship.remove("Darth Vader");
			
			System.out.println(starship);
		}
		
		// Empties the HashMap
		starship.clear();
		
		System.out.println(starship);
		
		/*
		 *  LinkedHashMaps retain order of inputs and entries
		 *  1st argument is the initial capacity of the map
		 *  
		 *  2nd argument is the load factor, or how full the map can be before it is made bigger
		 *  Default of '0.75f' which means the map will get bigger when 75% of the map's space has been filled
		 *  
		 *  3rd argument is a boolean value which specifies the ordering mode
		 *  If 'false' or unspecified, the insertion order prevails, if 'true' then the access order prevails, with the most recently
		 *  accessed elements being relegated to the bo
		 */
		LinkedHashMap<String, String> starshipOrdered = new LinkedHashMap<>(4, 0.75f, false);
		starshipOrdered.put("Luke Skywalker", "T-65B X-Wing");
		starshipOrdered.put("Han Solo", "YT-1300F Light Freighter");
		starshipOrdered.put("Darth Vader", "Super Star Destroyer");
		
		for(Map.Entry<String, String> entry: starship.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue());
		}
		

	}
}
