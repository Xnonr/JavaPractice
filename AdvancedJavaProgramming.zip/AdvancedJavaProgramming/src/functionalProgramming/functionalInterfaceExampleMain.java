package functionalProgramming;

// Lambdas were introduced to improve the messiness and complexity of functional interfaces
public class functionalInterfaceExampleMain {

	public static void main(String[] args) {
		
		FunctionalInterfaceExample greetingMessage = new FunctionalInterfaceExample() {
			
			/*
			 * Because FunctionalInterfaceExample has an abstract method with no implementation, a new
			 * implementation has to be added every time an instance of the interface is created
			 * Also known as an anonymous inner class
			 */
			@Override
			public void greet(String name) {
				//throw new UnsupportedOperationException("Not yet supported.");
				System.out.println("Hello " + name + ".");
			}
		};
		
		greetingMessage.greet("Padme Amidala");
		
		// Lambda version of the above code, using less code and being cleaner
		FunctionalInterfaceExample greetingMessageLambda = (String name) -> {
			System.out.println("Hello " + name + ".");
		};
		
		greetingMessageLambda.greet("Obi-Wan Kenobi");
	}
}
