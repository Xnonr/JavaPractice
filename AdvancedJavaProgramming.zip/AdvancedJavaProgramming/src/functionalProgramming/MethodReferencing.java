package functionalProgramming;

public class MethodReferencing {

	public static void main(String[] args) {
		
		Square square1 = new Square(4);
		
		// Original Lambda
		Shapes shapes1 = (Square square) -> {
			return square.calculateArea();
		};
		
		// Method Referencing Version
		Shapes shapes2 = Square::calculateArea;

		System.out.println("Area: " + shapes1.getArea(square1));
		System.out.println("Area: " + shapes2.getArea(square1));
		
	}
}
