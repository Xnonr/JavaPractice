package functionalProgramming;

/*
 * Streams are a way to iterate over collections in java without using for each loops
 * 
 * For each loops utilize external iteration
 * An iterator object is created, controlling the iteration process, calling the next method to move to the next object until the collection's end
 * Issues:
 * Difficult to write a program which can run 2 different external iterators in parallel
 * A lot of boilerplate code is required, reducing legibility, think many large and nested for loops
 * Difficult to abstract away behavior, what you are doing is intimately tied to how you are doing it
 * 
 * Streams use internal iteration
 * A stream object is created and elements are added to said object as it finds what is being searched for
 * Much more computationally efficient
 */

import java.util.ArrayList;

// Streams are much easier and generally more legible than multiple nested for loops, if statements and the like in complex situations
public class Streams {

	public static void main(String[] args) {
		
		ArrayList<Book> books = populateLibrary();
		
		/*
		 * With streams, you can have as many lazy methods as desired but only one eager method as with a regular method, as
		 * only 1 thing can be returned
		 * All of the implementation is all done under the hood, and the code rendered much shorter and clearer to understand
		 */
		
		// Filters out only those books whose authors' names begin with the letter 'O'
		books.stream().filter(book -> {
			return book.getAuthor().startsWith("O");
		// Filters out only those books from the first filtered list whose title's begin with the letter 'E'
		}).filter(book -> {
			return book.getTitle().startsWith("E");
		// Prints of the filtered array list
		}).forEach(System.out::println);
		
		/*
		 *  Parallel Streams allows for the usage of multiple cores, and should be adjusted to how many core the computer the code is run on
		 *  Should only be used when truly large amounts of data are involved, otherwise the gain in time is minimal
		 *  and it may be even more efficient to use a single stream
		 */
		books.parallelStream().filter(book -> {
			return book.getAuthor().startsWith("O");
		}).filter(book -> {
			return book.getTitle().startsWith("E");
		}).forEach(System.out::println);
	
	}
	
	static ArrayList<Book> populateLibrary() {
		
		ArrayList<Book> books = new ArrayList<Book>();
		
		books.add(new Book("The Hitchhiker's Guide to the Galaxy", "Douglas Adams"));
		books.add(new Book("The Restaurant at the End of the Universe", "Douglas Adams"));
		
		books.add(new Book("The War of the Worlds", "H. G. Wells"));
		
		books.add(new Book("Against a Dark Background", "Ian M. Banks"));
		books.add(new Book("Use of Weapons", "Ian M. Banks"));
		
		books.add(new Book("The Foundation Trilogy", "Isaac Asimov"));
		
		books.add(new Book("The Three-Body Problem", "Liu Cixin"));
		
		books.add(new Book("Ender's Game", "Orson Scott Card"));
		books.add(new Book("Ender's Shadow", "Orson Scott Card"));
		books.add(new Book("Shadow of the Hegemon", "Orson Scott Card"));
		
		books.add(new Book("Starship Troopers", "Robert A. Heinlein"));
		
		return books;
	}
}
