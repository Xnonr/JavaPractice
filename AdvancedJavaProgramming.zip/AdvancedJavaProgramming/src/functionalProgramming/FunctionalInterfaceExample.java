package functionalProgramming;

/*
 * Lambdas represent the implementation of a functional interface
 * A functional interface is an interface with only one abstract method
 * A functional interface allows programmers to pass around code as data within Java
 */

@FunctionalInterface
public interface FunctionalInterfaceExample {
	
	public abstract void greet(String name);
}
