package functionalProgramming;

@FunctionalInterface
public interface Shapes {

	public abstract int getArea(Square person);
}
