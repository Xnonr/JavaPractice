package inputOutput;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/* Buffered readers allow for the working of lines of characters with multiple input encodings, which allows for the reading of files
 * in multiple languages from all around the world; this is a typical use of input streams
 * 
 */

public class BufferedReader {

	public static void main(String[] args) {
		
		File myFile = new File("exampleFile.txt");
		
		/* A scanner would be simpler and shorter, but reads each section as a token as opposed to buffered reader simply returning
		 * a continous stream, buffered reader is also synchronized, meaning it is thread same and is faster than a scanner
		**/
//		try {
//			BufferedReader reader = new BufferedReader(new FileReader(myFile)); // Tutorial is FUBAR
//			String line;
//			
//			while((line = reader.toString()) != null) {
//				System.out.println(line);
//			}
			
			
		// FileNotFound Exception extends IOException, and as other exceptions related to IO may arise this is what will be caught instead
//		} catch(IOException ioException) {
//			
//		}

	}

}
