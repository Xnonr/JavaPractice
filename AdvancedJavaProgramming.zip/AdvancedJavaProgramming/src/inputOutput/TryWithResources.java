package inputOutput;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/*
 * When utilizing input and output resources it is important to use try with resources whenever possible.
 * This ensures that all resources are closed automatically without having to worry about manually closing all resources.
 * If said resources aren't properly closed, code leaking sources may pop up.
 * Especially if there are multiple resources interacting with one another.
 */

public class TryWithResources {

	public static void main(String[] args) {
		
		/* 
		 * Tutorial is FUBAR, probably outdated or deprecated
		 * Buffered reader wrapped around a String reader
		 * Objects which implement the auto-closable interface are resources
		 */
//		try(BufferedReader reader = new BufferedReader(new StringReader("Hello World!"));
//				StringWriter writer = new StringWriter();) {
//			// Utilizing a reader to read and string then a writer to write out what is read
//			BufferedReader reader = new BufferedReader(new StringReader("Hello World!"));
//			writer.write(reader.readLine());
//			
//			System.out.println(writer.toString());
//			
//		} catch(IOException ioException) {
//			
//		}

	}

}
