package inputOutput;

import java.util.Scanner;

/* InputStream & OutputStream: Abstract classes that cannot be instantiated though each have several concrete implementations, move bytes
 * Output Streams: Write out data, FileOutputStream, ByteArrayOutputStream, etc.
 * Input Streams: Read in data, FileInputStream, ByteArrayInputStream, FilterInputStream, etc.
 * 
 * Reader & Writer: Abstract classes similar in concept and function to Input and Output streams, but move characters around instead
 * Characters are easier and more intuitive to work with than bytes, handle Unicode and other character encoding issues that bytes do not
 * */


public class PersonCreator {
	
	public static void main(String[] args) {
		
		// Scanner is serving as an input stream
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter a name: ");
		
		// Finds and returns the next token from the scanner, which in this case will be a person's name
		String name1 = scanner.next();
		
		System.out.print("Enter an age: ");
		
		int age1 = scanner.nextInt();
		
		System.out.print("Enter a phone number: ");
		
		Long phoneNumber1 = scanner.nextLong();
		
		Person person1 = new Person(name1, age1, phoneNumber1);
		
		// Simpler and more direct route
		System.out.print("Enter a name, age and phone number: ");
		
		// The scanner will understand that when a space is detected, it marks a separation between different tokens
		// the method useDelimiter tells the scanner to use something other than a space to seperate tokens
		String name2 = scanner.next();
		int age2 = scanner.nextInt();
		Long phoneNumber2 = scanner.nextLong();
		
		Person person2 = new Person(name2, age2, phoneNumber2);
		
		
	}

}
