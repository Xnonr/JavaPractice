package substitutionPrinciple;

public class Starship {

	@Override
	public String toString() {
		return("Starship.");
	}
}
