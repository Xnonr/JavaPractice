package substitutionPrinciple;

public class Starfighter extends Starship {

	@Override
	public String toString() {
		return("Starfighter.");
	}
}
