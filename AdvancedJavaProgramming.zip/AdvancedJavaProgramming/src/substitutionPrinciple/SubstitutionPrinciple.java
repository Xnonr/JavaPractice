package substitutionPrinciple;

import java.util.ArrayList;
import java.util.List;

/* Liskov Substitution Principle:
 * Important concept in Object Oriented Programming (OOP) as it allows for the writing of maintainable and reusable code
 * If you have a variable of a given type you can assign it to a value that is a sub-type of that type
 */

public class SubstitutionPrinciple {

	public static void main(String[] args) {
		
		Starship starship1 = new Starship();
		Starfighter starfighter1 = new Starfighter();
		
		// As Starfighter is a sub-type of Starship, it can be passed into the same 'construct' method which takes in a Starship object
		// This is the substituion principle
		construct(starship1);
		construct(starfighter1);
		
		List<Starship> starships = new ArrayList();
		starships.add(new Starship());
		starships.add(new Starfighter());
		
		printStarships(starships);
		
		// The substitution principle however does work with types of lists
		List<Starfighter> starfighters = new ArrayList();
		starships.add(new Starfighter());
		starships.add(new Starfighter());
		
		// The line below is not applicable in this situation
		//printStarships(starfighters);

	}
	
	static void construct(Starship starship) {
		System.out.println("Constructing a new " + starship.toString());
	}
	
	static void printStarships(List<Starship> starships) {
		for(int index = 0; index < starships.size(); index++) {
			System.out.println(index + 1 + ": " + starships.get(index).toString());
		}
	}

}
