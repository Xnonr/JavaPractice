package threads;

/* Multithreaded Application Problems:
 * Much easier to develop multithreaded applications when threads don't interact, typically via shared variables
 * These can cause applications to become thread unsafe
 * 
 * Thread interactions can cause problems, including examples such as:
 * Race Conditions - Occurs when threads depend on relative timing by a scheduler
 * 
 * Data Races - Occurs when 2 or more threads within the same application access the same memory location concurrently
 * At least 1 thread requires write access, and the threads do not coordinate their access to said memory
 * Access order in these conditions is non deterministic and different results may be generated from run to run depending on said order
 * 
 * Cached Variable Problems
 * 
 * Threads can cause increased complexity, making debugging code far more difficult
 * Logic can be added to ensure that data is synchronized across threads, but to much synchronization can negatively affect stability,
 * leading to performance issues that can also affect an applications scalability
 */

public class ProblemsWithThreads {

	// Class level variables via static keyword, meaning there is only 1 place in memory where these values are stored
	static double a = 10;
	static double b;
	
	/* A ace condition will occur with this set up
	 * Thread A will see 'a = 10' and will therefore try to divide by 2, but will go to sleep before it can
	 * Meanwhile Thread B will set 'a = 12', sneaking in before A can continue
	 * When Thread A resumes, instead of a = 10, a = 12, and so the result will be an incorrect 12 instead of 5, a logic error
	 */
	public static void main(String[] args) {
		
		Runnable runnable1 = () -> {
			if(a == 10) {
				try {
					Thread.sleep(0);
					b = a / 2.0;
					
					System.out.println(Thread.currentThread().getName() + " : " + b);
				} catch(InterruptedException exception) {
					
				}
			}
		};
		
		Runnable runnable2 = () -> {
			a = 12;
		};
		
		Thread threadA = new Thread(runnable1, "ThreadA");
		Thread threadB = new Thread(runnable2, "ThreadB");
		
		threadA.start();
		threadB.start();
		
		// Expect Outputs:
		// 'ThreadA: 6.0' OR 'ThreadA: 5.0'
	}
}
