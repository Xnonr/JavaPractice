package threads;

public class TestJoinClass extends Thread {
	
	// Constructor assigns a user defined name to the thread
	public TestJoinClass(String name) {
		super(name);
	}
	
	// Because this class extends Thread, the run method must be overridden
	public void run() {
		for(int count = 1; count <= 5; count++) {
			// Since a static method is being used, either a try-catch or a throw statement must be added to the 'public void run()'
			try {
				// Stops the thread for 1/2 second
				Thread.sleep(500);
			} catch(Exception exception) {
				System.out.println(exception);
			}
			
			System.out.println(Thread.currentThread().getName() + " count = " + count);
		}
	}
}
