package threads;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* Concurrency Utilities:
 * 
 * Executors:
 * Defines a high level API for managing threads
 * Provides thread pool management
 * Separates thread creation and management from the rest of the main application
 * Simplify the creation of threads
 * 
 * Executor Interfaces:
 * Executor: Simple interface to support launching new tasks
 * ExecutorService: Sub-interface with the added feature of managing the life-cycle of individual tasks and the executor itself
 * Schedules ExecutorService: Sub-sub-interface that supports future tasks
 */

public class ThreadConcurrencyUtilities {

	public static void main(String[] args) {
		
		// Creates a pool of 5 threads
		ExecutorService executor = Executors.newFixedThreadPool(5);
		
		// As we are creating 10 threads but the executor pool only has 5, the 1st 5 will go first, then the last 5 will finish up
		for(int thread = 0; thread < 10; thread++) {
			Runnable worker = new WorkerThread("I'm Thread #" + thread);
			
			// Calls the execute method of ExecutorService
			executor.execute(worker);
		}
		
		// Will shutdown any threads which might have been used once but are no longer currently in use, and let those not done yet finish
		executor.shutdown();
		
		while(!executor.isTerminated()) {
			
		}
		
		// When the threads' work is complete, they once more become available within the thread pool and can start a new task
		System.out.println("Finished all threads.");
	}
}
