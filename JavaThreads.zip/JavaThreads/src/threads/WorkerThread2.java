package threads;

import java.util.concurrent.CountDownLatch;

public class WorkerThread2 extends Thread {
	
	private final CountDownLatch start;
	private final CountDownLatch end;
	
	WorkerThread2(CountDownLatch start, CountDownLatch end) {
		this.start = start;
		this.end = end;
	}
	
	public void run() {
		try {
			printInfo("Thread entered run().");
			
			// Waits before proceeding forward as the main thread reduces the wait count and the worker thread is allowed to proceed
			start.await();
			
			printInfo("Doing some work.");
			
			Thread.sleep(3000);
			
			// Reduces the end count
			end.countDown();
		} catch(InterruptedException exception) {
			System.err.println(exception);
		}
	}

	void printInfo(String message) {
		System.out.println(System.currentTimeMillis() + " : " + Thread.currentThread() + " : " + message);
	}
}
