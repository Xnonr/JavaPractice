package threads;

public class Countdown {
	
	public void printCount() {
		try {
			for(int count = 10; count > 0; count--) {
				System.out.println(" --- " + count);
			}
			System.out.println("Blast Off!");
		} catch(Exception exception) {
			System.out.println("Thread Interrupted.");
		}
	}
}
