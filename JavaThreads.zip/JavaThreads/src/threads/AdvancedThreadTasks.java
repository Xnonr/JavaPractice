package threads;

/* Thread Class:
 * Useful methods for thread management
 * Includes static and non-static methods
 * Static methods provide information about or affect the status of the current thread invoking the method
 * Non-static methods on the calling thread using the dot ('.') operator
 */

/* Static Methods:
 * activeCount() - Returns the estimated number of active threads in the current threads thread group and its subgroups
 * currentThread() - Returns a reference to the currently active executing thread object
 * enumerate(Thread[] threadArrayName) - Copies into the specified array every active thread in the current threads thread group and its subgroups
 * sleep(long milliseconds) - Causes the currently executive thread to sleep or temporarily cease execution for the specified number of milliseconds
 */

/* Non-Static Methods:
 * join() - Waits for the current thread to die, waits for the thread to complete before it rejoins the main program up to a specified amount of time
 * interrupt() - Interrupts and stops a thread object upon which the method is called
 */

public class AdvancedThreadTasks {

	public static void main(String[] args) {
		TestJoinClass thread1 = new TestJoinClass("Thread1");
		TestJoinClass thread2 = new TestJoinClass("Thread2");
		TestJoinClass thread3 = new TestJoinClass("Thread3");
		
		thread1.start();
		
		try {
			thread1.join();
		} catch(Exception exception) {
			System.out.println(exception);
		}
		
		thread2.start();
		
		// The 3rd thread won't start until the 2nd thread is completed
		thread3.start();
		
		/* Depending upon the number of processors of the hardware upon which this program runs, threads 2 and 3
		 * will either run concurrently or take turns
		 */
		
		/* Expected Output:
		 * Thread1 count = 1
		 * Thread1 count = 2
		 * Thread1 count = 3
		 * Thread1 count = 4
		 * Thread1 count = 5
		 * Thread3 count = 1
		 * Thread2 count = 1
		 * Thread3 count = 2
		 * Thread2 count = 2
		 * Thread3 count = 3
		 * Thread2 count = 3
		 * Thread2 count = 4
		 * Thread3 count = 4
		 * Thread2 count = 5
		 * Thread3 count = 5
		 */
	}
}
