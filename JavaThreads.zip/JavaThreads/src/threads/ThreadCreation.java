package threads;

/* Thread Definition:
 * Every java program has a default main thread
 * A thread is an independent path of code execution
 * Many threads can run concurrently within a java program
 * Threads can be used to perform time intensive tasks and run them in the background
 * This allows for applications to remain responsive with regards towards their users
 * 
 * Runnables are objects that encapsulate code sequences once a thread is created
 * Each thread executes a runnable object
 * Threads can initiate an asynchronous task
 * Asynchronous indicates that it can run concurrently rather than sequentially and therefore having to wait
 * 
 * The Java Virtual Machine (JVM) gives each thread its own private JVM stack, essentially its own private area of memory
 * This prevents threads from interfering with each other
 * The stack holds local variable and partial results
 * It also tracks next instructions and plays a part in calling methods and handling return values
 * 
 * Java supports threads either through the java.land.Thread class or the java.lang.Runnable interface
 * Threads are either daemon or non-daemon
 * A daemon thread does not prevent the JVM from exiting when the program finishes but the thread is still running, setDaemon(true)
 * Java garbage collection is a daemon thread, as it continues to do its work behind the scenes within preventing the JVM from exiting
 * By default, java threads are non-daemons, including the main method
 * The program ends when all non-daemon threads have died
 */

/* Thread Lifecycle:
 * New Thread() - start()
 * Runnable - run()
 * Running - wait()
 * Waiting / Sleep - notify() / elapsed time
 * Dead
 */

public class ThreadCreation {

	public static void main(String[] args) {
	
		// Creates a thread using a class which implements runnable
		(new Thread(new HelloRunnable())).start();	
		
		// Creates a thread using a class that extends Thread
		(new HelloThread()).start();
		
		// Creates a runnable object
		Runnable runnableNotLambda = new Runnable() {
			@Override
			public void run() {
				// Performs some work inside of the thread
				System.out.println("Hello from " + Thread.currentThread().getName() + " not using lambda.");
			}
		};
		
		// Creates a runnable object whilst utilizing lambda notation
		Runnable runnableLambda = () -> System.out.println("Hello from " + Thread.currentThread().getName() + " using lambda notation.");
		
		// Creates and starts a thread using the first runnable object, having been given a name within the arguments
		Thread thread1 = new Thread(runnableNotLambda, "Thread 1");
		thread1.start();
		
		// Creates and starts a thread using the second runnable object whilst having no given name
		Thread thread2 = new Thread(runnableLambda);
		thread2.start();
		
		// Threads are automatically named, starting from 0, if they are not given a name within the code
		
		/* Expected Output:
		 * Hello from Thread-0 a thread created by implementing a runnable interface.
		 * Hello from Thread-1 created by extending the Thread class. 
		 * Hello from Thread 1 not using lambda. 
		 * Hello from Thread-2 using lambda notation.
		 */
	}
}
