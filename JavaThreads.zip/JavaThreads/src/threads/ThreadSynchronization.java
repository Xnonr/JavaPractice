package threads;

/* Thread Synchronization:
 * Used to solve race conditions, data races and cached variable problems
 * JVM feature which ensures 2 or more concurrent threads simultaneously execute a critical section which must be accessed in a serial manner
 * Ensures threads can safely update shared variables 
 * Can be applied by marking methods or code blocks
 * 
 * Read Modify Write:
 * Synchronized code is known as critical sections
 * JVM supports this via monitors and the monitor enter and exit JVM instructions
 * Every java object is associated with a monitor
 * Before a thread enters a critical section it must get a lock on the monitor
 * If the monitor is already locked, the thread is blocked until the monitor is unlocked
 * 
 * When a thread locks a monitor in a multi-core, multiprocessor environment, the values of the shared variables that are stored in main memory are
 * read into the copies of these variables that are stored in the threads working / local / cache memory
 * 
 * This ensures the threads work with the most recent values and not out-dated ones
 * When the thread unlocks the monitor when leaving the critical section, the values are then copied into the shared variables and written back
 * to the main memory
 */

public class ThreadSynchronization {

	// Defines a class variable called counter
	static int counter = 1;
	
	/* 3 Steps:
	 * Read the counter value
	 * Add 1 to the counter variable
	 * Stored the new value back into counter
	 */
	public static void main(String[] args) {
		
		// Utilizes a lambda notation for the runnable method
		Runnable runnable1 = () -> {
			
			// Locking on a method
			//System.out.println("ID Value: " + getID());
			
			// Locking on an object
			ID id = new ID();
			System.out.println("ID Value: " + id.getID());
		};
		
		Thread thread1 = new Thread(runnable1, "Thread1");
		thread1.start();
		
		Thread thread2 = new Thread(runnable1, "Thread2");
		thread2.start();
	}
	
	/* Synchronized Methods:
	 * As a result of not paying attention to synchronization, non unique ID values might be produced
	 * By adding the keyword synchronized to a method's header, this prevents 2 or more threads from accessing the same critical code
	 * A lock has been added to this method prevent 2 or more threads from accessing it at the same time
	 */
	//public static int getID() {
	public static synchronized int getID() {
		return counter++;
	}
	
	/* Method Synchronization Expected Outputs:
	 * ID Value: 1 OR ID Value: 1
	 * ID Value: 2    ID Value: 1
	 */
	
	/* Object Synchronization Expected Outputs:
	 * ID Value: 0 OR ID Value: 1
	 * ID Value: 1    ID Value: 0
	 */

}
