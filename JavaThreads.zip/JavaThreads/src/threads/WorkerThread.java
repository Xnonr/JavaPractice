package threads;

public class WorkerThread implements Runnable {
	
	private final String message;
	
	// Constructor assigns a message when creating a new thread
	public WorkerThread(String message) {
		this.message = message;
	}
	
	// Prints out the name of the current thread
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " (Start) message = " + message);
		
		// Calls work to be done method in order to simulate a delay
		workToBeDone();
		
		// The worker thread is now done and available for another task if need be
		System.out.println(Thread.currentThread().getName() + " (End) ");
	}
	
	// Is a busy method to simulate work done by the worker thread
	private void workToBeDone() {
		try {
			Thread.sleep(2000);
		} catch(InterruptedException exception) {
			exception.printStackTrace();
		}
	}

}
