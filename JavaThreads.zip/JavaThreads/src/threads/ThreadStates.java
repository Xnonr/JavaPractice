package threads;

/* Thread State: 
 * Each thread object has a state that includes the following:
 * Name
 * Alive / Dead
 * Execution State
 * Priority
 * Daemon / Non-Daemon Status
 */

/* Thread Execution States:
 * New - Created but not yet started
 * Runnable - A thread executing in the Java Virtual Machine (JVM)
 * Blocked - Blocked waiting for a monitor to be unlocked
 * Waiting - Waiting to be notified to continue
 * Timed Waiting - Waiting with a time limit
 * Terminated - A thread that has completed execution
 */

public class ThreadStates {

	// Throwing an InterruptedException is required when using a static method for the Thread class is desired
	public static void main(String[] args) throws InterruptedException {
		
		// Prints out information about the current thread
		// No threads have yet been created or started, but the main method always automatically gets assigned to a main thread
		printThreadInformation();
		
		// Creates a runnable object that prints information about the thread
		Runnable runnable1 = () -> {
			Thread threadRunnable1 = Thread.currentThread();
			
			printThreadInformation();
		};
		
		// Creates the first thread and prints out its information before calling start()
		Thread thread1 = new Thread(runnable1, "Thread thread1");
		
		printThreadInformation();
		
		thread1.start();
		
		// Creates the second thread with only a runnable object and no name
		Thread thread2 = new Thread(runnable1);
		thread2.start();
		
		// Puts the main thread, essentially the whole program, to sleep for 2 seconds
		// Sleep uses milliseconds - 1 second = 1000 milliseconds
		Thread.sleep(2000);
		
		// Changes the name of the second thread and prints out its information
		thread2.setName("Thread thread2");
		
		printThreadInformation();
		
		// Priority 5 is the default priority
		
	}
	
	// Prints out information about a thread in a formatted way
	public static void printThreadInformation() {
		System.out.printf("%s is %salive and is %s state%n and priority %d \n", 
				Thread.currentThread().getName(),
				Thread.currentThread().isAlive() ? "" : "not ",
				Thread.currentThread().getState(),
				Thread.currentThread().getPriority());
	}
}
