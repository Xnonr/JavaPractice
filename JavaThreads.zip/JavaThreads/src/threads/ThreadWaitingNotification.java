package threads;

/* Waiting & Notification API:
 * Communication is important when threads share data
 * 
 * Waiting Methods:
 * void wait() - Causes the thread to wait until another thread invokes the notify or notify all method for the appropriate object, or is
 * interrupted by another thread whilst waiting
 * 
 * void wait(long milliseconds) - Specifies a time frame for how long the thread should wait, starting back up either when it receives a 
 * notification or the time has elapsed, whichever comes first
 * 
 * void wait(long milliseconds, long nanoseconds) - Finer precision
 * 
 * 
 * Notification Methods:
 * void notify() - Wakes up a single thread waiting on the given object's monitor, if multiple threads are waiting, only 1 is chosen arbitrarily
 * 
 * void notifyAll() - Leverages object's condition queue, waiting threads are known as wait set, the current thread must be the object's monitor to
 * invoke this method, otherwise an IllegalMonitorStateException is thrown
 */

// Deadlock: When 2 or more threads are blocked forever, waiting for each other

public class ThreadWaitingNotification {

	public static void main(String[] args) {
		
		ThreadB threadB = new ThreadB();
		
		threadB.start();
		
		// Main thread will wait until threadB has completed its summation, then will continue
		synchronized(threadB) {
			try {
				System.out.println("Waiting for the 2nd thread to reach completion...");
				threadB.wait();
			} catch(InterruptedException exception) {
				exception.printStackTrace();
			}
			
			System.out.println("Total: " + threadB.total);
			
			// Without the main method waiting, the total would be 0 due to it not letting threadB finish its calculations
			
			/* Expected Output:
			 * Waiting for the 2nd thread to reach completion...
			 * Total: 10
			 */
		}
	}
}

class ThreadB extends Thread {
	
	int total;
	
	// Must override the run method since Thread is being extended
	@Override
	public void run() {
		// Applying a synchronized lock on this ThreadB object
		synchronized(this) {
			for (int count = 0; count < 10; count++) {
				total += 1;
			}
			
			notify();
		}
	}
}
