package threads;

// FUBAR: Cannot be found
import java.util.concurrent.CountDownLatch;

/* Thread Synchronizers:
 * Latches
 * Barriers
 * Semaphores
 * Exchangers
 */

/* Countdown Latch:
 * It causes 1 or more threads to wait at a gate until another thread open the gate
 * It contains a count value and logic to decrement the count until it reaches zero
 * 
 * Countdown Methods:
 * void await() - Forces the calling thread to wait until the latch has reach 0 or the calling thread is interrupted, an an exception is thrown
 * boolean await(long timeout, TimeUnit u) - Calling thread must wait until 0 or the timeout value in time units expires
 * void countdown() - Decrements the call, releasing all threads when count reaches 0
 * long getCout() - Returns the current count for testing and debugging
 * String toString - Returns a string identifying the current latch as well as its state in brackets with the count value
 */

public class ThreadSynchronizers {

	public static void main(String[] args) {
		
		// Prevents any of the worker threads from starting until the default main thread is ready for them to start
		CountDownLatch start = new CountDownLatch(1);
		
		// Causes the main thread to wait until all worker threads have finished, goes from 4 to 0
		CountDownLatch end = new CountDownLatch(4);
		
		// Creates and starts the threads
		for(int thread = 0; thread < 5; thread++) {
			new Thread(new WorkerThread2(start, end)).start();
		}
		
		try {
			System.out.print("Main thread is doing something.");
			
			// Thread sleeps for 1 second
			Thread.sleep(1000);
			
			// Lets all threads proceed
			start.countDown();
			
			System.out.print("Main thread is doing something else whilst the worker threads are working.");
			
			// Waits for all threads to finish, then the default main thread will be able to continue and finish itself in turn
			end.await();
		} catch(InterruptedException exception) {
			System.err.println(exception);
		}
	}
}
