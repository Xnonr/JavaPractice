package threads;

/* Synchronized Block:
 * Identified by a special header, which identifies the object for the lock
 */

public class SynchronizedBlocks {

	public static void main(String[] args) {
		
		Countdown countdown1 = new Countdown();
		Runnable runnable1 = () -> {
			
			// The synchronized Countdown class object, if left commented than the threads walk over one another and the countdown is kaput
			synchronized(countdown1) {
				countdown1.printCount();
			}
		};
		
		Thread thread1 = new Thread(runnable1, "Thread1");
		Thread thread2 = new Thread(runnable1, "Thread2");
		
		thread1.start();
		thread2.start();
	}
}
