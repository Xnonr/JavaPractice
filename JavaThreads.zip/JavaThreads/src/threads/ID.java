package threads;

// The ID class containing the synchronized keyword prevents multiple threads from accessing the 'getID()' method as the same time
public class ID {
	
	// Variable initializes itself to a value of '0' by default
	private static int counter;
	
	public static synchronized int getID() {
		return counter++;
	}
}
